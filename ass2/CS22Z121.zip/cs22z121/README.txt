run CS22Z121.py
